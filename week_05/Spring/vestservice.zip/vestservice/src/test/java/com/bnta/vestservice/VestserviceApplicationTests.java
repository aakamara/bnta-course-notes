package com.bnta.vestservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VestserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
