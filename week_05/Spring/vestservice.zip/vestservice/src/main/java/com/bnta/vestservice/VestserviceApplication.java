package com.bnta.vestservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VestserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VestserviceApplication.class, args);
	}

}
